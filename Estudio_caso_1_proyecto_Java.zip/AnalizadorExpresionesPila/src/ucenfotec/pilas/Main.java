package ucenfotec.pilas;

import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * Punto de entrada del programa.
 * Universidad CENFOTEC - SOFT-10 Estructuras de Datos - Primer estudio de caso.
 * Aplicación de las pilas al análisis de expresiones aritméticas.
 *
 * El menú permite:
 *  - Operar la pila directamente (push, pop, peek, etc.) con tokens.
 *  - Definir variables numéricas.
 *  - Analizar una expresión: validarla, convertirla a postfija y evaluarla,
 *    con la opción de ver el estado de la pila en cada paso.
 */
public class Main {

    private static final Scanner ENTRADA = new Scanner(System.in);
    private static final Pila PILA_MANUAL = new Pila();
    private static final Map<String, Double> VARIABLES = new TreeMap<>();
    private static final AnalizadorExpresiones ANALIZADOR = new AnalizadorExpresiones();

    public static void main(String[] args) {
        ANALIZADOR.setMostrarTraza(true); // por defecto se muestra el paso a paso
        mostrarBienvenida();
        menu();
        System.out.println("\nGracias por usar el analizador. ¡Hasta luego!");
    }

    /** Menú principal: se repite hasta que el usuario elige salir. */
    private static void menu() {
        boolean continuar = true;
        while (continuar) {
            System.out.println("\n=============== MENÚ PRINCIPAL ===============");
            System.out.println(" 1. Analizar una expresión aritmética");
            System.out.println(" 2. Operar la pila de tokens manualmente");
            System.out.println(" 3. Definir o cambiar una variable");
            System.out.println(" 4. Ver variables definidas");
            System.out.println(" 5. Mostrar paso a paso: " + (ANALIZADOR.isMostrarTraza() ? "ACTIVADO" : "DESACTIVADO"));
            System.out.println(" 6. Ayuda");
            System.out.println(" 0. Salir");
            System.out.println("==============================================");

            switch (leerOpcion("Elija una opción: ")) {
                case 1:
                    analizarExpresion();
                    break;
                case 2:
                    menuPila();
                    break;
                case 3:
                    definirVariable();
                    break;
                case 4:
                    mostrarVariables();
                    break;
                case 5:
                    ANALIZADOR.setMostrarTraza(!ANALIZADOR.isMostrarTraza());
                    System.out.println("Paso a paso " + (ANALIZADOR.isMostrarTraza() ? "activado." : "desactivado."));
                    break;
                case 6:
                    mostrarAyuda();
                    break;
                case 0:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no válida. Escriba un número del menú.");
            }
        }
    }

    // ------------------------------------------------------------------
    // Opción 1: análisis completo de una expresión
    // ------------------------------------------------------------------

    private static void analizarExpresion() {
        System.out.println("\nEscriba la expresión (ej.: (base + 3) * altura / 2 - x^2)");
        String texto = leerLinea("> ");
        try {
            List<Token> tokens = Tokenizador.tokenizar(texto);
            mostrarTokens(tokens);

            String error = ANALIZADOR.validarParentesis(tokens);
            if (error == null) {
                error = ANALIZADOR.validarSintaxis(tokens);
            }
            if (error != null) {
                System.out.println("\n[X] Expresión inválida: " + error);
                return;
            }
            System.out.println("\n[OK] La expresión es válida.");

            List<Token> postfija = ANALIZADOR.infijaAPostfija(tokens);
            System.out.println("\nNotación postfija: " + Tokenizador.unir(postfija));

            pedirVariablesFaltantes(tokens);
            double resultado = ANALIZADOR.evaluarPostfija(postfija, VARIABLES);
            System.out.println("\n>>> Resultado: " + AnalizadorExpresiones.formatear(resultado));
        } catch (IllegalArgumentException | IllegalStateException | ArithmeticException e) {
            System.out.println("\n[X] Error: " + e.getMessage());
        }
    }

    /** Pide el valor de cada variable de la expresión que aún no tenga uno. */
    private static void pedirVariablesFaltantes(List<Token> tokens) {
        for (String nombre : AnalizadorExpresiones.variablesUsadas(tokens)) {
            if (!VARIABLES.containsKey(nombre)) {
                VARIABLES.put(nombre, leerNumero("Valor de la variable " + nombre + ": "));
            }
        }
    }

    private static void mostrarTokens(List<Token> tokens) {
        System.out.println("\nTokens reconocidos (" + tokens.size() + "):");
        for (int i = 0; i < tokens.size(); i++) {
            System.out.printf("  %2d. %s%n", i + 1, tokens.get(i).describir());
        }
    }

    // ------------------------------------------------------------------
    // Opción 2: operaciones básicas de la pila
    // ------------------------------------------------------------------

    private static void menuPila() {
        boolean continuar = true;
        while (continuar) {
            System.out.println("\n----------- PILA DE TOKENS -----------");
            System.out.println(PILA_MANUAL.dibujar());
            System.out.println(" Tamaño: " + PILA_MANUAL.size());
            System.out.println("--------------------------------------");
            System.out.println(" 1. push   - Apilar un token");
            System.out.println(" 2. pop    - Desapilar el token del tope");
            System.out.println(" 3. peek   - Consultar el tope");
            System.out.println(" 4. isEmpty / size");
            System.out.println(" 5. clear  - Vaciar la pila");
            System.out.println(" 0. Volver al menú principal");

            try {
                switch (leerOpcion("Elija una opción: ")) {
                    case 1:
                        String texto = leerLinea("Token (número, variable, operador o paréntesis): ");
                        Token token = Token.desdeTexto(texto);
                        PILA_MANUAL.push(token);
                        System.out.println("Se apiló: " + token.describir());
                        break;
                    case 2:
                        System.out.println("Se desapiló: " + PILA_MANUAL.pop().describir());
                        break;
                    case 3:
                        System.out.println("Tope actual: " + PILA_MANUAL.peek().describir());
                        break;
                    case 4:
                        System.out.println("¿Vacía?: " + (PILA_MANUAL.isEmpty() ? "sí" : "no")
                                + " | Elementos: " + PILA_MANUAL.size());
                        break;
                    case 5:
                        PILA_MANUAL.clear();
                        System.out.println("La pila quedó vacía.");
                        break;
                    case 0:
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (PilaVaciaException | IllegalArgumentException e) {
                System.out.println("[X] " + e.getMessage());
            }
        }
    }

    // ------------------------------------------------------------------
    // Opciones 3 y 4: variables
    // ------------------------------------------------------------------

    private static void definirVariable() {
        String nombre = leerLinea("Nombre de la variable: ").trim();
        if (!nombre.matches("[A-Za-z_][A-Za-z0-9_]*")) {
            System.out.println("[X] Nombre inválido: debe empezar con letra o _ y no tener espacios.");
            return;
        }
        double valor = leerNumero("Valor de " + nombre + ": ");
        VARIABLES.put(nombre, valor);
        System.out.println(nombre + " = " + AnalizadorExpresiones.formatear(valor));
    }

    private static void mostrarVariables() {
        if (VARIABLES.isEmpty()) {
            System.out.println("No hay variables definidas todavía.");
            return;
        }
        System.out.println("\nVariables definidas:");
        for (Map.Entry<String, Double> e : VARIABLES.entrySet()) {
            System.out.println("  " + e.getKey() + " = " + AnalizadorExpresiones.formatear(e.getValue()));
        }
    }

    // ------------------------------------------------------------------
    // Textos de apoyo
    // ------------------------------------------------------------------

    private static void mostrarBienvenida() {
        System.out.println("==============================================");
        System.out.println("   ANALIZADOR DE EXPRESIONES ARITMÉTICAS");
        System.out.println("   Implementado con una pila enlazada");
        System.out.println("   SOFT-10 Estructuras de Datos - CENFOTEC");
        System.out.println("==============================================");
    }

    private static void mostrarAyuda() {
        System.out.println("\nAYUDA");
        System.out.println(" - Números: 7, 3.5     - Variables: x, base, tasa_1");
        System.out.println(" - Operadores: +  -  *  /  %  ^ (potencia)  y el menos unario: -x");
        System.out.println(" - Paréntesis: ( )");
        System.out.println(" - Precedencia: ^  >  menos unario  >  * / %  >  + -");
        System.out.println(" - Si una variable no tiene valor, el programa lo pedirá al evaluar.");
        System.out.println(" - Con el paso a paso activado verá el contenido de la pila en cada token.");
    }

    // ------------------------------------------------------------------
    // Lectura segura de datos
    // ------------------------------------------------------------------

    private static String leerLinea(String mensaje) {
        System.out.print(mensaje);
        if (!ENTRADA.hasNextLine()) {
            return "0"; // fin de la entrada: equivale a salir
        }
        return ENTRADA.nextLine();
    }

    private static int leerOpcion(String mensaje) {
        while (true) {
            String texto = leerLinea(mensaje).trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException e) {
                System.out.println("Escriba solo el número de la opción.");
            }
        }
    }

    private static double leerNumero(String mensaje) {
        while (true) {
            String texto = leerLinea(mensaje).trim().replace(',', '.');
            try {
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                System.out.println("Valor no numérico. Intente de nuevo.");
            }
        }
    }
}
