package ucenfotec.pilas;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Las tres aplicaciones de la pila al análisis de expresiones aritméticas:
 * <ol>
 *   <li>Validación de paréntesis balanceados.</li>
 *   <li>Conversión de notación infija a postfija (algoritmo Shunting-yard de Dijkstra).</li>
 *   <li>Evaluación de la expresión postfija.</li>
 * </ol>
 * Las tres usan la {@link Pila} propia del proyecto. Si se activa la traza,
 * cada método imprime el estado de la pila en cada paso.
 */
public class AnalizadorExpresiones {

    private boolean mostrarTraza;

    public AnalizadorExpresiones() {
        this.mostrarTraza = false;
    }

    public void setMostrarTraza(boolean mostrarTraza) {
        this.mostrarTraza = mostrarTraza;
    }

    public boolean isMostrarTraza() {
        return mostrarTraza;
    }

    // ------------------------------------------------------------------
    // 1. Validación de paréntesis
    // ------------------------------------------------------------------

    /**
     * Cada "(" se apila; cada ")" desapila su pareja. La expresión está
     * balanceada si nunca se intenta desapilar de una pila vacía y la pila
     * queda vacía al final.
     *
     * @return null si es válida, o un mensaje que describe el error.
     */
    public String validarParentesis(List<Token> tokens) {
        Pila pila = new Pila();
        traza("\n--- Validación de paréntesis ---");
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            if (t.getTipo() == TipoToken.PARENTESIS_IZQ) {
                pila.push(t);
                traza(String.format("%-4s push(\"(\")   pila: %s", t, pila));
            } else if (t.getTipo() == TipoToken.PARENTESIS_DER) {
                if (pila.isEmpty()) {
                    return "Hay un \")\" sin su \"(\" correspondiente (token " + (i + 1) + ").";
                }
                pila.pop();
                traza(String.format("%-4s pop()         pila: %s", t, pila));
            }
        }
        if (!pila.isEmpty()) {
            return "Faltan " + pila.size() + " paréntesis de cierre \")\".";
        }
        traza("Resultado: paréntesis balanceados.");
        return null;
    }

    /** Verifica que operandos y operadores alternen correctamente (p. ej., rechaza "3 + * 4"). */
    public String validarSintaxis(List<Token> tokens) {
        boolean esperaOperando = true;
        for (int i = 0; i < tokens.size(); i++) {
            Token t = tokens.get(i);
            if (esperaOperando) {
                if (t.esOperando()) {
                    esperaOperando = false;
                } else if (t.getTipo() == TipoToken.PARENTESIS_IZQ || t.esUnario()) {
                    // sigue esperando un operando
                } else {
                    return "Se esperaba un número, una variable o \"(\" en el token "
                            + (i + 1) + " (\"" + t + "\").";
                }
            } else {
                if (t.esOperador() && !t.esUnario()) {
                    esperaOperando = true;
                } else if (t.getTipo() == TipoToken.PARENTESIS_DER) {
                    // sigue esperando un operador
                } else {
                    return "Se esperaba un operador o \")\" en el token "
                            + (i + 1) + " (\"" + t + "\").";
                }
            }
        }
        if (esperaOperando) {
            return "La expresión termina de forma incompleta.";
        }
        return null;
    }

    // ------------------------------------------------------------------
    // 2. Conversión infija -> postfija (Shunting-yard)
    // ------------------------------------------------------------------

    /**
     * Los operandos pasan directo a la salida; los operadores y "(" esperan
     * en la pila hasta que su turno queda definido por la precedencia.
     */
    public List<Token> infijaAPostfija(List<Token> tokens) {
        List<Token> salida = new ArrayList<>();
        Pila operadores = new Pila();
        traza("\n--- Conversión infija -> postfija ---");
        traza(String.format("%-6s %-26s %-18s %s", "Token", "Acción", "Pila", "Salida"));

        for (Token t : tokens) {
            String accion;
            switch (t.getTipo()) {
                case NUMERO:
                case VARIABLE:
                    salida.add(t);
                    accion = "a la salida";
                    break;
                case PARENTESIS_IZQ:
                    operadores.push(t);
                    accion = "push(\"(\")";
                    break;
                case PARENTESIS_DER:
                    while (operadores.peek().getTipo() != TipoToken.PARENTESIS_IZQ) {
                        salida.add(operadores.pop());
                    }
                    operadores.pop(); // descarta el "(" sin enviarlo a la salida
                    accion = "pop hasta \"(\"";
                    break;
                default: // OPERADOR
                    int sacados = 0;
                    while (!operadores.isEmpty() && debeSalirAntes(operadores.peek(), t)) {
                        salida.add(operadores.pop());
                        sacados++;
                    }
                    operadores.push(t);
                    accion = (sacados > 0 ? "pop x" + sacados + ", " : "") + "push(\"" + t + "\")";
                    break;
            }
            traza(String.format("%-6s %-26s %-18s %s", t, accion, operadores, Tokenizador.unir(salida)));
        }
        while (!operadores.isEmpty()) {
            salida.add(operadores.pop());
        }
        traza(String.format("%-6s %-26s %-18s %s", "fin", "vaciar la pila", operadores, Tokenizador.unir(salida)));
        return salida;
    }

    /** ¿El operador del tope debe pasar a la salida antes de apilar el actual? */
    private boolean debeSalirAntes(Token tope, Token actual) {
        if (!tope.esOperador()) {
            return false; // un "(" detiene el desapilado
        }
        if (actual.esUnario()) {
            return false; // un operador unario prefijo nunca desaloja al anterior
        }
        return tope.precedencia() > actual.precedencia()
                || (tope.precedencia() == actual.precedencia() && !actual.asociaDerecha());
    }

    // ------------------------------------------------------------------
    // 3. Evaluación de la expresión postfija
    // ------------------------------------------------------------------

    /**
     * Cada operando se apila; cada operador desapila sus operandos, calcula
     * y apila el resultado. Al final, la pila contiene un único valor.
     *
     * @param variables valores de las variables numéricas de la expresión
     */
    public double evaluarPostfija(List<Token> postfija, Map<String, Double> variables) {
        Pila pila = new Pila();
        traza("\n--- Evaluación de la expresión postfija ---");
        traza(String.format("%-6s %-26s %s", "Token", "Acción", "Pila"));
        for (Token t : postfija) {
            if (t.esOperando()) {
                double valor = valorDe(t, variables);
                pila.push(new Token(TipoToken.NUMERO, formatear(valor)));
                traza(String.format("%-6s %-26s %s", t, "push(" + formatear(valor) + ")", pila));
            } else if (t.esUnario()) {
                double a = Double.parseDouble(pila.pop().getValor());
                pila.push(new Token(TipoToken.NUMERO, formatear(-a)));
                traza(String.format("%-6s %-26s %s", t, "pop, push(-" + formatear(a) + ")", pila));
            } else {
                double b = Double.parseDouble(pila.pop().getValor());
                double a = Double.parseDouble(pila.pop().getValor());
                double r = operar(a, b, t.getValor());
                pila.push(new Token(TipoToken.NUMERO, formatear(r)));
                String calculo = "pop x2: " + formatear(a) + " " + t + " " + formatear(b) + " = " + formatear(r);
                traza(String.format("%-6s %-26s %s", t, calculo, pila));
            }
        }
        if (pila.size() != 1) {
            throw new IllegalStateException("La expresión postfija no es válida.");
        }
        return Double.parseDouble(pila.pop().getValor());
    }

    private double valorDe(Token t, Map<String, Double> variables) {
        if (t.getTipo() == TipoToken.NUMERO) {
            return Double.parseDouble(t.getValor());
        }
        Double v = variables.get(t.getValor());
        if (v == null) {
            throw new IllegalStateException("La variable \"" + t.getValor() + "\" no tiene valor asignado.");
        }
        return v;
    }

    private double operar(double a, double b, String operador) {
        switch (operador) {
            case "+":
                return a + b;
            case "-":
                return a - b;
            case "*":
                return a * b;
            case "/":
                if (b == 0) {
                    throw new ArithmeticException("División entre cero.");
                }
                return a / b;
            case "%":
                if (b == 0) {
                    throw new ArithmeticException("Módulo entre cero.");
                }
                return a % b;
            case "^":
                return Math.pow(a, b);
            default:
                throw new IllegalArgumentException("Operador desconocido: " + operador);
        }
    }

    // ------------------------------------------------------------------
    // Utilidades
    // ------------------------------------------------------------------

    /** Devuelve las variables de la expresión, sin repetir y en orden de aparición. */
    public static Set<String> variablesUsadas(List<Token> tokens) {
        Set<String> nombres = new LinkedHashSet<>();
        for (Token t : tokens) {
            if (t.getTipo() == TipoToken.VARIABLE) {
                nombres.add(t.getValor());
            }
        }
        return nombres;
    }

    /** Muestra enteros sin ".0" y decimales con hasta 6 cifras. */
    public static String formatear(double valor) {
        if (valor == Math.rint(valor) && !Double.isInfinite(valor) && Math.abs(valor) < 1e15) {
            return String.valueOf((long) valor);
        }
        return String.format(java.util.Locale.US, "%.6f", valor).replaceAll("0+$", "");
    }

    private void traza(String linea) {
        if (mostrarTraza) {
            System.out.println(linea);
        }
    }
}
