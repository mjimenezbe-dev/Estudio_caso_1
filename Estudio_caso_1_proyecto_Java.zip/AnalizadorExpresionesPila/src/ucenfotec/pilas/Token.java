package ucenfotec.pilas;

/**
 * Unidad mínima de una expresión aritmética (lexema + tipo).
 * Es el dato que guarda cada {@link Nodo} de la {@link Pila}.
 * La clase es inmutable: una vez creado, un token no cambia.
 */
public final class Token {

    /** Símbolo que representa el menos unario, para distinguirlo de la resta. */
    public static final String MENOS_UNARIO = "~";

    private final TipoToken tipo;
    private final String valor;

    public Token(TipoToken tipo, String valor) {
        if (tipo == null || valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("Un token necesita tipo y valor.");
        }
        this.tipo = tipo;
        this.valor = valor;
    }

    public TipoToken getTipo() {
        return tipo;
    }

    public String getValor() {
        return valor;
    }

    /** @return true si el token es un número literal o una variable. */
    public boolean esOperando() {
        return tipo == TipoToken.NUMERO || tipo == TipoToken.VARIABLE;
    }

    public boolean esOperador() {
        return tipo == TipoToken.OPERADOR;
    }

    public boolean esUnario() {
        return esOperador() && MENOS_UNARIO.equals(valor);
    }

    /**
     * Precedencia del operador: a mayor número, antes se evalúa.
     * Los paréntesis no tienen precedencia porque se manejan aparte.
     */
    public int precedencia() {
        if (!esOperador()) {
            return -1;
        }
        switch (valor) {
            case "+":
            case "-":
                return 1;
            case "*":
            case "/":
            case "%":
                return 2;
            case MENOS_UNARIO:
                return 3; // -2^2 = -(2^2), como en matemática
            case "^":
                return 4;
            default:
                return -1;
        }
    }

    /** La potencia y el menos unario asocian a la derecha: 2^3^2 = 2^(3^2). */
    public boolean asociaDerecha() {
        return "^".equals(valor) || MENOS_UNARIO.equals(valor);
    }

    /** Crea el token correspondiente a un lexema escrito por el usuario. */
    public static Token desdeTexto(String texto) {
        String t = texto.trim();
        if (t.equals("(")) {
            return new Token(TipoToken.PARENTESIS_IZQ, t);
        }
        if (t.equals(")")) {
            return new Token(TipoToken.PARENTESIS_DER, t);
        }
        if (t.matches("[+\\-*/%^~]")) {
            return new Token(TipoToken.OPERADOR, t);
        }
        if (t.matches("-?\\d+(\\.\\d+)?")) {
            return new Token(TipoToken.NUMERO, t);
        }
        if (t.matches("[A-Za-z_][A-Za-z0-9_]*")) {
            return new Token(TipoToken.VARIABLE, t);
        }
        throw new IllegalArgumentException("\"" + texto + "\" no es un token válido.");
    }

    @Override
    public String toString() {
        return valor;
    }

    /** Versión descriptiva, útil para mostrar el contenido de la pila. */
    public String describir() {
        return valor + "  [" + tipo.getDescripcion() + "]";
    }
}
