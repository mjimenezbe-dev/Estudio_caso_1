package ucenfotec.pilas;

/**
 * Pila LIFO (último en entrar, primero en salir) implementada con nodos
 * enlazados. Todas las operaciones básicas son O(1): solo se trabaja
 * sobre el tope, nunca se recorre la estructura.
 */
public class Pila {

    private Nodo tope;
    private int tamano;

    public Pila() {
        tope = null;
        tamano = 0;
    }

    /** Apila (push) un token: el nuevo nodo pasa a ser el tope. */
    public void push(Token token) {
        if (token == null) {
            throw new IllegalArgumentException("No se puede apilar un token nulo.");
        }
        tope = new Nodo(token, tope);
        tamano++;
    }

    /** Desapila (pop): retira y devuelve el token del tope. */
    public Token pop() {
        if (isEmpty()) {
            throw new PilaVaciaException("pop()");
        }
        Token dato = tope.getDato();
        Nodo anterior = tope;
        tope = tope.getSiguiente();
        anterior.setSiguiente(null); // se desconecta para facilitar la recolección
        tamano--;
        return dato;
    }

    /** Consulta (peek) el token del tope sin retirarlo. */
    public Token peek() {
        if (isEmpty()) {
            throw new PilaVaciaException("peek()");
        }
        return tope.getDato();
    }

    public boolean isEmpty() {
        return tope == null;
    }

    public int size() {
        return tamano;
    }

    /** Vacía la pila por completo. */
    public void clear() {
        while (!isEmpty()) {
            pop();
        }
    }

    /**
     * Representación horizontal, del fondo al tope: [ ( + * ]
     * Se usa en las trazas paso a paso.
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "[ ]";
        }
        String[] valores = new String[tamano];
        Nodo actual = tope;
        for (int i = tamano - 1; i >= 0; i--) {
            valores[i] = actual.getDato().getValor();
            actual = actual.getSiguiente();
        }
        return "[ " + String.join(" ", valores) + " ]";
    }

    /** Dibujo vertical de la pila, con el tope arriba, como casillas. */
    public String dibujar() {
        if (isEmpty()) {
            return "  (pila vacía)";
        }
        StringBuilder sb = new StringBuilder();
        String borde = "  +------------------------------+";
        sb.append(borde).append('\n');
        Nodo actual = tope;
        boolean esTope = true;
        while (actual != null) {
            sb.append(String.format("  | %-28s |", actual.getDato().describir()));
            if (esTope) {
                sb.append("  <- tope");
                esTope = false;
            }
            sb.append('\n').append(borde).append('\n');
            actual = actual.getSiguiente();
        }
        return sb.toString();
    }
}
