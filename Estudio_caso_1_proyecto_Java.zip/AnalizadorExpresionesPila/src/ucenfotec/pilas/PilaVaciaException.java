package ucenfotec.pilas;

/**
 * Se lanza al intentar sacar o consultar un elemento de una pila vacía
 * (subdesbordamiento o "underflow").
 */
public class PilaVaciaException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public PilaVaciaException(String operacion) {
        super("No se puede ejecutar " + operacion + ": la pila está vacía.");
    }
}
