package ucenfotec.pilas;

/**
 * Clasifica cada token de una expresión aritmética.
 * El enunciado exige contemplar números literales, variables numéricas,
 * operadores y paréntesis.
 */
public enum TipoToken {
    /** Número literal, por ejemplo 3, 2.5 o 10. */
    NUMERO("Número"),
    /** Variable numérica, por ejemplo x, base o tasa1. */
    VARIABLE("Variable"),
    /** Operador aritmético: + - * / % ^ y el menos unario (~). */
    OPERADOR("Operador"),
    /** Paréntesis de apertura "(". */
    PARENTESIS_IZQ("Paréntesis izq."),
    /** Paréntesis de cierre ")". */
    PARENTESIS_DER("Paréntesis der.");

    private final String descripcion;

    TipoToken(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
