package ucenfotec.pilas;

import java.util.ArrayList;
import java.util.List;

/**
 * Análisis léxico: convierte el texto de una expresión en una lista de tokens.
 * Reconoce números (enteros o decimales), variables, operadores y paréntesis,
 * y distingue el menos unario (-x) de la resta (a - b).
 */
public final class Tokenizador {

    private Tokenizador() {
        // Clase utilitaria: no se instancia.
    }

    public static List<Token> tokenizar(String expresion) {
        if (expresion == null || expresion.isBlank()) {
            throw new IllegalArgumentException("La expresión está vacía.");
        }
        List<Token> tokens = new ArrayList<>();
        int i = 0;
        while (i < expresion.length()) {
            char c = expresion.charAt(i);

            if (Character.isWhitespace(c)) {
                i++;
            } else if (Character.isDigit(c) || c == '.') {
                int inicio = i;
                while (i < expresion.length()
                        && (Character.isDigit(expresion.charAt(i)) || expresion.charAt(i) == '.')) {
                    i++;
                }
                String numero = expresion.substring(inicio, i);
                if (!numero.matches("\\d+(\\.\\d+)?")) {
                    throw new IllegalArgumentException("Número mal formado: \"" + numero + "\".");
                }
                tokens.add(new Token(TipoToken.NUMERO, numero));
            } else if (Character.isLetter(c) || c == '_') {
                int inicio = i;
                while (i < expresion.length()
                        && (Character.isLetterOrDigit(expresion.charAt(i)) || expresion.charAt(i) == '_')) {
                    i++;
                }
                tokens.add(new Token(TipoToken.VARIABLE, expresion.substring(inicio, i)));
            } else if (c == '(') {
                tokens.add(new Token(TipoToken.PARENTESIS_IZQ, "("));
                i++;
            } else if (c == ')') {
                tokens.add(new Token(TipoToken.PARENTESIS_DER, ")"));
                i++;
            } else if ("+-*/%^".indexOf(c) >= 0) {
                String op = String.valueOf(c);
                if (c == '-' && esPosicionUnaria(tokens)) {
                    op = Token.MENOS_UNARIO;
                } else if (c == '+' && esPosicionUnaria(tokens)) {
                    i++; // el más unario no cambia el valor: se ignora
                    continue;
                }
                tokens.add(new Token(TipoToken.OPERADOR, op));
                i++;
            } else {
                throw new IllegalArgumentException(
                        "Carácter no válido '" + c + "' en la posición " + (i + 1) + ".");
            }
        }
        return tokens;
    }

    /** Un signo es unario si está al inicio, después de "(" o después de otro operador. */
    private static boolean esPosicionUnaria(List<Token> tokens) {
        if (tokens.isEmpty()) {
            return true;
        }
        Token anterior = tokens.get(tokens.size() - 1);
        return anterior.esOperador() || anterior.getTipo() == TipoToken.PARENTESIS_IZQ;
    }

    /** Une los tokens con espacios, por ejemplo "a b c * +". */
    public static String unir(List<Token> tokens) {
        StringBuilder sb = new StringBuilder();
        for (Token t : tokens) {
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(t.getValor());
        }
        return sb.toString();
    }
}
