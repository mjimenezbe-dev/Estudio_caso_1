package ucenfotec.pilas;

/**
 * Nodo de la pila enlazada. Guarda un {@link Token} y la referencia
 * al nodo que está inmediatamente debajo de él en la pila.
 */
public class Nodo {

    private final Token dato;
    private Nodo siguiente;

    public Nodo(Token dato) {
        this(dato, null);
    }

    public Nodo(Token dato, Nodo siguiente) {
        this.dato = dato;
        this.siguiente = siguiente;
    }

    public Token getDato() {
        return dato;
    }

    /** @return el nodo de abajo, o null si este es el fondo de la pila. */
    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
}
