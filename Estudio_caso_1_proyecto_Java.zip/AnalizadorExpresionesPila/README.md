# Analizador de expresiones aritméticas con pilas

**Universidad CENFOTEC · SOFT-10 Estructuras de Datos · SCV5 · C3-2026**
Primer estudio de caso — Manuel Jiménez Benavides

Programa en Java que aplica una pila enlazada (clases `Nodo` y `Pila`) al análisis de expresiones aritméticas con números literales, variables numéricas, operadores y paréntesis.

## Qué hace

1. **Tokeniza** la expresión (números, variables, operadores `+ - * / % ^`, menos unario y paréntesis).
2. **Valida** los paréntesis con una pila y revisa que operandos y operadores alternen bien.
3. **Convierte** de notación infija a postfija con el algoritmo *Shunting-yard* de Dijkstra.
4. **Evalúa** la expresión postfija con una pila, pidiendo el valor de las variables que falten.
5. Permite **operar la pila directamente** (push, pop, peek, isEmpty, size, clear).

Con la opción "paso a paso" el programa muestra el contenido de la pila después de cada token.

## Estructura

```
src/ucenfotec/pilas/
├── Main.java                   main() y menu()
├── Pila.java                   pila LIFO enlazada
├── Nodo.java                   nodo que guarda un Token
├── Token.java                  dato del nodo: tipo + valor, precedencia
├── TipoToken.java              NUMERO, VARIABLE, OPERADOR, PARENTESIS_IZQ, PARENTESIS_DER
├── Tokenizador.java            texto -> lista de tokens
├── AnalizadorExpresiones.java  validación, infija -> postfija, evaluación
└── PilaVaciaException.java     error de pila vacía
```

## Cómo ejecutarlo

Requiere Java 11 o superior.

```bash
javac -encoding UTF-8 -d out src/ucenfotec/pilas/*.java
java -cp out ucenfotec.pilas.Main
```

En IntelliJ IDEA o NetBeans: abra la carpeta, marque `src` como carpeta de fuentes y ejecute `ucenfotec.pilas.Main`.

## Ejemplo

```
> (a + 3) * b - 8 / 2        con a = 5, b = 2
Notación postfija: a 3 + b * 8 2 / -
>>> Resultado: 12
```
